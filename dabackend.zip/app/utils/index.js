const mongodb = require('./lib/mongodb');
const nodemailer = require('./lib/nodemailer');

module.exports = {
    mongodb,
    nodemailer
};
